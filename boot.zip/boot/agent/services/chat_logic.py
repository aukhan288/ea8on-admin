from models.t5_model import chat_model

knowledge_base = ""

def set_knowledge_base(text):
    global knowledge_base
    knowledge_base = text

def get_response(query):
    if not knowledge_base:
        return "No knowledge base found. Please upload a PDF first."
    
    prompt = f"answer the question: {query} based on: {knowledge_base[:1000]}"
    return chat_model.generate_response(prompt)


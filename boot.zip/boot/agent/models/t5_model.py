from transformers import T5ForConditionalGeneration, T5Tokenizer

MODEL_NAME = "t5-small"

class ChatModel:
    def __init__(self):
        self.tokenizer = T5Tokenizer.from_pretrained(MODEL_NAME)
        self.model = T5ForConditionalGeneration.from_pretrained(MODEL_NAME)

    def generate_response(self, prompt):
        input_ids = self.tokenizer.encode(prompt, return_tensors="pt", truncation=True, max_length=512)
        output_ids = self.model.generate(input_ids, max_length=150)
        return self.tokenizer.decode(output_ids[0], skip_special_tokens=True)

chat_model = ChatModel()

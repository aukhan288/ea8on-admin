from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request
import os
from services.pdf_extractor import extract_text_from_pdf
from services.chat_logic import set_knowledge_base, get_response

app = FastAPI()

# Serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Setup Jinja2 templates
templates = Jinja2Templates(directory="templates")

# Upload Directory
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.get("/")
async def home(request: Request):
    """Render the chatbot UI."""
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/upload_pdf/")
async def upload_pdf(file: UploadFile = File(...)):
    """Uploads a PDF and extracts text as knowledge base."""
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        buffer.write(await file.read())

    extracted_text = extract_text_from_pdf(file_path)
    if not extracted_text.strip():
        return {"error": "No extractable text found in the PDF."}
    
    set_knowledge_base(extracted_text)
    return {"message": "PDF uploaded and processed successfully."}

@app.post("/chat/")
async def chat(query: str):
    """Chat with the bot using the uploaded PDF knowledge base."""
    response = get_response(query)
    return {"response": response}
